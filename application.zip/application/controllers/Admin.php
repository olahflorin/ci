<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once(APPPATH . 'controllers/Webshop.php');

class Admin extends Webshop {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('producatori');
		$this->load->model('produscatalog');
	}
	
	public function adauga_produs() {
		$date = array( 
			'producatori' => $this->producatori->obtine_producatori(),
			'salvat'	=> false
		);
		
		if(!empty($_POST)) {
			$produs = array();
			$produs['nume'] = $this->input->post('nume');
			$produs['descriere'] = $this->input->post('descriere');
			$produs['id_categorie'] = $this->input->post('id_categorie');
			$produs['id_producator'] = $this->input->post('id_producator');
			$produs['pret'] = $this->input->post('pret');
			$this->db->insert('produse',$produs);
			$date['salvat'] = true;
		}
		
		$this->load->view('header');
		$this->load->view('admin/adauga',$date);
		$this->load->view('footer');
	}
	
	public function modifica_produs() {
		$idprodus = $this->uri->segment(3);
		$date = array('salvat' => false);
		if(!empty($_POST)) {
			$produs = array();
			$produs['nume'] = $this->input->post('nume');
			$produs['descriere'] = $this->input->post('descriere');
			$produs['id_categorie'] = $this->input->post('id_categorie');
			$produs['id_producator'] = $this->input->post('id_producator');
			$produs['pret'] = $this->input->post('pret');
			
			$this->db->where('id', $idprodus);
			$this->db->update('produse',$produs);
			$date['salvat'] = true;
		}
		
		$produs = $this->produscatalog->obtineProdus($idprodus);

		$date['produs'] = $produs;
		$date['producatori'] = $this->producatori->obtine_producatori();
		
		$this->load->view('header');
		$this->load->view('admin/modifica',$date);
		$this->load->view('footer');
	}
}