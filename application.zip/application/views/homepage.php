<?php $this->view('homepage/slider'); ?>
<section>
	<div class="container">
		<div class="row">	
			<div class="col-sm-12 padding-right">
				<?php $this->view('homepage/promovate'); ?>
				<?php $this->view('homepage/recomandate'); ?>
			</div>
		</div>
	</div>
</section>